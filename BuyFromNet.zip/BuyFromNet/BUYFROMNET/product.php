<?php

include('header.php');

?>
<?php
include('Template/_products.php');

include('Template/_top-sale.php');


?>




<?php

include('footer.php');

?>